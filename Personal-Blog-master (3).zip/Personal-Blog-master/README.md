# Personal Blog

First project for Udacity Front-end Nanodegree.

## Getting Started

Make sure node.js and yarn are installed.

### Installing

Run this command :

```
yarn install
```
