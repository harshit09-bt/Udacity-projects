import {} from './js/app';
import { getKeys } from './js/createTrips';
import { registerClient } from './js/regest';

registerClient();
// get keys for API Requests
getKeys();
// styles
import './style/assets.scss';

/// font Awesome icons
import '@fortawesome/fontawesome-free/js/fontawesome';
import '@fortawesome/fontawesome-free/js/solid';
import '@fortawesome/fontawesome-free/js/regular';
import '@fortawesome/fontawesome-free/js/brands';

console.log('CHANGE!!');
